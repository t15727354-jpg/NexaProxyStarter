# C1garro Proxy — projeto Android original

Interface Android original inspirada apenas no estilo geral de um painel de ferramentas, com identidade vermelha/preta.

## Estado real das funções
- Interface, cartões, campo de texto e botões: implementados.
- Botão para abrir opções de desenvolvedor: implementado (abre as configurações do Android; o usuário configura o ADB manualmente).
- Validação da key: apenas demonstração; não consulta servidor nem verifica credenciais.
- Iniciar/parar proxy: apenas demonstração; não cria túnel, VPN nem proxy de rede.
- Automação ADB: não implementada.
- Não há código copiado do LEEK Team V6.

## Compilar pelo celular usando GitHub Actions
1. Extraia este ZIP.
2. Crie um repositório novo no GitHub.
3. Envie todos os arquivos mantendo a estrutura de pastas. O arquivo oculto `.github/workflows/build-apk.yml` precisa ser enviado.
4. Abra a aba **Actions** do repositório. Se solicitado, habilite workflows.
5. Se o workflow não iniciar automaticamente após o envio, abra **Build C1garro Proxy APK** e toque **Run workflow**.
6. Aguarde a execução terminar com um visto verde.
7. Na página da execução, procure **Artifacts** e baixe `C1garroProxy-debug-apk.zip`.
8. Extraia o ZIP e instale `app-debug.apk` no Android. Talvez seja necessário autorizar instalação desse arquivo pelo navegador/gerenciador de arquivos.

## Requisitos do build
- Gradle 8.9
- JDK 17
- Android Gradle Plugin 8.7.3
- Android SDK 35

Este é um APK de depuração. Antes de distribuir publicamente, crie uma versão de lançamento e revise segurança, privacidade e assinatura.
