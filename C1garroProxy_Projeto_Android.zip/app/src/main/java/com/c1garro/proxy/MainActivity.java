package com.c1garro.proxy;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(13, 13, 16);
    private final int PANEL = Color.rgb(27, 27, 32);
    private final int RED = Color.rgb(232, 35, 53);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(177, 177, 187);
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(24));
        page.setBackgroundColor(BG);
        scroll.addView(page);

        TextView brand = new TextView(this);
        brand.setText("C1GARRO");
        brand.setTextColor(RED);
        brand.setTextSize(13);
        brand.setLetterSpacing(0.22f);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(brand);

        TextView title = new TextView(this);
        title.setText("PROXY");
        title.setTextColor(WHITE);
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(4);
        page.addView(title, titleLp);

        TextView subtitle = text("Painel Android • edição 1.0", 14, MUTED);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(4);
        page.addView(subtitle, subLp);

        View line = new View(this);
        line.setBackgroundColor(RED);
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(dp(62), dp(4));
        lineLp.topMargin = dp(20);
        lineLp.bottomMargin = dp(22);
        page.addView(line, lineLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(round(PANEL, 18));
        page.addView(card, matchWrap());

        card.addView(text("AUTENTICAÇÃO", 12, RED));
        TextView keyLabel = text("Sua key", 14, WHITE);
        LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(-1, -2);
        klp.topMargin = dp(14);
        card.addView(keyLabel, klp);

        EditText key = new EditText(this);
        key.setSingleLine(true);
        key.setHint("Digite sua key (demo)");
        key.setHintTextColor(MUTED);
        key.setTextColor(WHITE);
        key.setTextSize(15);
        key.setPadding(dp(12), 0, dp(12), 0);
        key.setBackground(round(Color.rgb(43,43,49), 10));
        LinearLayout.LayoutParams keyLp = new LinearLayout.LayoutParams(-1, dp(52));
        keyLp.topMargin = dp(8);
        card.addView(key, keyLp);

        Button validate = button("VALIDAR KEY (DEMO)", RED);
        LinearLayout.LayoutParams vLp = matchWrap();
        vLp.topMargin = dp(12);
        card.addView(validate, vLp);
        validate.setOnClickListener(v -> {
            if (key.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "Digite uma key para testar a interface.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Demonstração: nenhuma validação real foi feita.", Toast.LENGTH_LONG).show();
            }
        });

        LinearLayout adbCard = new LinearLayout(this);
        adbCard.setOrientation(LinearLayout.VERTICAL);
        adbCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        adbCard.setBackground(round(PANEL, 18));
        LinearLayout.LayoutParams adbLp = matchWrap();
        adbLp.topMargin = dp(16);
        page.addView(adbCard, adbLp);
        adbCard.addView(text("CONEXÃO ADB", 12, RED));
        TextView adbInfo = text("Abra as opções de desenvolvedor para configurar a depuração sem fio manualmente.", 14, MUTED);
        LinearLayout.LayoutParams aiLp = new LinearLayout.LayoutParams(-1, -2);
        aiLp.topMargin = dp(10);
        adbCard.addView(adbInfo, aiLp);

        Button adb = button("ABRIR OPÇÕES DO DESENVOLVEDOR", Color.rgb(54,54,62));
        LinearLayout.LayoutParams adbBtnLp = matchWrap();
        adbBtnLp.topMargin = dp(12);
        adbCard.addView(adb, adbBtnLp);
        adb.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });

        LinearLayout proxyCard = new LinearLayout(this);
        proxyCard.setOrientation(LinearLayout.VERTICAL);
        proxyCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        proxyCard.setBackground(round(PANEL, 18));
        LinearLayout.LayoutParams pcLp = matchWrap();
        pcLp.topMargin = dp(16);
        page.addView(proxyCard, pcLp);
        proxyCard.addView(text("CONTROLE DO PROXY", 12, RED));
        status = text("Status: demonstração parada", 14, MUTED);
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(-1, -2);
        stLp.topMargin = dp(10);
        proxyCard.addView(status, stLp);

        Button start = button("INICIAR (DEMO)", RED);
        LinearLayout.LayoutParams startLp = matchWrap();
        startLp.topMargin = dp(12);
        proxyCard.addView(start, startLp);
        start.setOnClickListener(v -> status.setText("Status: modo demonstração — proxy não conectado"));

        Button stop = button("PARAR DEMO", Color.rgb(54,54,62));
        LinearLayout.LayoutParams stopLp = matchWrap();
        stopLp.topMargin = dp(8);
        proxyCard.addView(stop, stopLp);
        stop.setOnClickListener(v -> status.setText("Status: demonstração parada"));

        TextView note = text("Aviso: esta versão é uma interface original de demonstração. Não valida keys em servidor, não cria túnel/proxy de rede e não executa comandos ADB automaticamente.", 12, MUTED);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(18);
        page.addView(note, noteLp);

        TextView footer = text("C1GARRO PROXY • BUILD 1.0", 11, RED);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fLp = new LinearLayout.LayoutParams(-1, -2);
        fLp.topMargin = dp(24);
        page.addView(footer, fLp);

        setContentView(scroll);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }
    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(WHITE);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackground(round(color, 12));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        return b;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
